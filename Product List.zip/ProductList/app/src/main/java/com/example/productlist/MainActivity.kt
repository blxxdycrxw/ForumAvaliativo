package com.example.productlist

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import android.view.LayoutInflater
import com.example.product_list.R

class MainActivity : AppCompatActivity() {
    @SuppressLint("DefaultLocale")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val products = listOf(
            Product("Arroz", "Vasconcelos", 20.00, 12, "001", 10, 5, 4),
            Product("Feijão", "Vasconcelos", 10.00, 15, "002", 5, 6, 5),
            Product("Detergente", "Ypé", 1.99, 100, "405", 20, 10, 9)
        )

        val productListLayout = findViewById<LinearLayout>(R.id.product_list)

        val inflater = LayoutInflater.from(this)
        for (product in products) {
            val productView = inflater.inflate(R.layout.item_product, productListLayout, false)
            val productNameTextView = productView.findViewById<TextView>(R.id.product_name)
            val productPriceTextView = productView.findViewById<TextView>(R.id.product_price)
            val productQuantityTextView = productView.findViewById<TextView>(R.id.product_quantity)
            val productDiscountTextView = productView.findViewById<TextView>(R.id.product_discount)
            val productBrandTextView = productView.findViewById<TextView>(R.id.product_brand)
            val productReferenceTextView = productView.findViewById<TextView>(R.id.product_reference)
            val productOfferTextView = productView.findViewById<TextView>(R.id.product_offer)
            val productNameSpannable = SpannableString(product.name)
            productNameSpannable.setSpan(StyleSpan(android.graphics.Typeface.BOLD), 0, productNameSpannable.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            productNameSpannable.setSpan(RelativeSizeSpan(1.5f), 0, productNameSpannable.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            productNameTextView.text = productNameSpannable

            productPriceTextView.text = getString(R.string.label_valor, String.format("%.2f", product.price))
            productQuantityTextView.text = getString(R.string.label_qtdade, product.quantity)
            productDiscountTextView.text = getString(R.string.label_desconto, product.discount1)
            productBrandTextView.text = getString(R.string.label_marca, product.brand)
            productReferenceTextView.text = getString(R.string.label_ref, product.reference)
            productOfferTextView.text = getString(R.string.label_leve_pague, product.discount2, product.discount3)
            productListLayout.addView(productView)
        }

        val titleTextView = findViewById<TextView>(R.id.title)
        val titleSpannable = SpannableString(titleTextView.text)
        titleSpannable.setSpan(StyleSpan(android.graphics.Typeface.BOLD), 0, titleSpannable.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        titleTextView.text = titleSpannable
    }
}

data class Product(
    val name: String,
    val brand: String,
    val price: Double,
    val quantity: Int,
    val reference: String,
    val discount1: Int,
    val discount2: Int,
    val discount3: Int
)